export enum PlanId {
  FREE = "free",
  BASIC = "basic",
  PREMIUM = "premium",
}
