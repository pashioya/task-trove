import type { Application } from "express";
import { healthCheck, helloMonday } from "@/app/controllers";

export enum Route {
  HEALTH_CHECK = "/",
  HELLO_MONDAY = "/hello-monday",
  FAV_ICON = "/favicon.ico",
}

export default function (app: Application) {
  app.get(Route.HEALTH_CHECK, healthCheck);
  app.post(Route.HELLO_MONDAY, helloMonday);
}
